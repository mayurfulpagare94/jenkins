#!/bin/bash
# Destroys the demo resources created by local provider
set -e
cd envs/dev
terraform destroy -auto-approve -var-file=terraform.tfvars
cd ../..
echo "Destroyed demo resources. You can remove state_output/ if present."
