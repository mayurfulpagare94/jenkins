#!/bin/bash
# Run this from the repo root to init, plan, and apply for the dev env.
set -e
echo "Switching to envs/dev and running terraform..."
cd envs/dev
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan -var-file=terraform.tfvars
terraform apply -auto-approve "tfplan"
echo "Created files under state_output/"
cd ../..
