Terraform Module Structure Practice Project
==========================================

Overview:
- This project is designed to let you practice Terraform modules locally without needing a cloud account.
- It uses the "local" provider and creates small files to simulate resources (VPC and Compute instances).
- When you're ready, you can switch to the real GCP provider by following the comments in provider.tf and modules.

Project layout:
terraform_practice_project/
├─ modules/
│  ├─ network/
│  │  ├─ main.tf
│  │  ├─ variables.tf
│  │  └─ outputs.tf
│  └─ compute/
│     ├─ main.tf
│     ├─ variables.tf
│     └─ outputs.tf
├─ envs/
│  └─ dev/
│     ├─ main.tf
│     ├─ terraform.tfvars
├─ provider.tf
├─ variables.tf
├─ outputs.tf
├─ run.sh
└─ destroy.sh

Quick start (Linux):
1. cd terraform_practice_project/envs/dev
2. terraform init
3. ./../../run.sh      # runs fmt, validate, plan, apply (creates files under ./state_output/)
4. Inspect ./state_output/ to see files created by modules
5. ./../../destroy.sh # destroys created resources

Switch to GCP later:
- Open provider.tf and follow the commented GCP provider block.
- Replace module implementations in modules/* with GCP resources (examples are commented).
- Set up GCP credentials and backend, then run terraform init and apply.

Notes:
- This project uses the local_file resource so it does not create real cloud infra.
- It's intended for learning module wiring, variables, outputs, and lifecycle.
